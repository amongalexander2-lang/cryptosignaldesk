const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('marketAPI', Object.freeze({
  getSnapshot: (intervals, symbols) => ipcRenderer.invoke('market:snapshot', intervals, symbols),
  getScannerSnapshot: (intervals) => ipcRenderer.invoke('market:scanner-snapshot', intervals),
  getCatalog: (forceRefresh = false) => ipcRenderer.invoke('market:catalog', forceRefresh === true)
}));
