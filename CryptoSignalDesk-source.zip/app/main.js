const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');

const WATCHLIST = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT', 'LTCUSDT', 'DOTUSDT', 'BCHUSDT'];
const INTERVALS = new Set(['15m', '1h', '4h', '1d', '1w']);
const API_HOSTS = ['https://data-api.binance.vision', 'https://api.binance.com'];
const MIN_DAILY_QUOTE_VOLUME = 2_000_000;
const STABLECOINS = new Set(['USDC', 'FDUSD', 'TUSD', 'DAI', 'USDP', 'USDE', 'BUSD', 'EUR', 'GBP']);
const MAX_WATCHLIST = 50;
let catalogCache = null;
let catalogCacheAt = 0;
let exchangeInfoCache = null;
let exchangeInfoCacheAt = 0;
let exchangeInfoPromise = null;
let requestCooldownUntil = 0;

function makeWindow() {
  const win = new BrowserWindow({
    width: 1480,
    height: 940,
    minWidth: 1060,
    minHeight: 720,
    backgroundColor: '#080d13',
    title: 'Crypto Signal Desk',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (url !== win.webContents.getURL()) event.preventDefault();
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

async function request(pathname, query = '') {
  if (Date.now() < requestCooldownUntil) {
    const seconds = Math.ceil((requestCooldownUntil - Date.now()) / 1000);
    throw new Error(`Market data is cooling down after a Binance rate limit. Try again in about ${seconds} seconds.`);
  }
  let lastError;
  for (const host of API_HOSTS) {
    try {
      const response = await fetch(`${host}${pathname}${query}`, { signal: AbortSignal.timeout(12000), headers: { 'User-Agent': 'CryptoSignalDesk/1.0' } });
      if (!response.ok) {
        const error = new Error(response.status === 429 || response.status === 418
          ? `Binance rate-limited this IP (HTTP ${response.status}); wait before refreshing.`
          : `Market source returned HTTP ${response.status}`);
        if (response.status === 429 || response.status === 418) {
          error.noFailover = true;
          const retryAfter = response.headers.get('retry-after');
          const seconds = Number(retryAfter);
          const wait = Number.isFinite(seconds) && seconds > 0 ? seconds * 1000 : Math.max(30000, Date.parse(retryAfter || '') - Date.now() || 60000);
          requestCooldownUntil = Math.max(requestCooldownUntil, Date.now() + wait);
        }
        throw error;
      }
      return await response.json();
    } catch (error) { lastError = error; if (error.noFailover) break; }
  }
  throw new Error(lastError?.message || 'Market data is unavailable');
}

async function mapLimit(items, limit, mapper) {
  const output = new Array(items.length);
  let cursor = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      output[index] = await mapper(items[index]);
    }
  }));
  return output;
}

async function getExchangeInfo(forceRefresh = false) {
  if (!forceRefresh && exchangeInfoCache && Date.now() - exchangeInfoCacheAt < 10 * 60 * 1000) return exchangeInfoCache;
  if (!exchangeInfoPromise) {
    exchangeInfoPromise = request('/api/v3/exchangeInfo').then(result => {
      exchangeInfoCache = result; exchangeInfoCacheAt = Date.now(); return result;
    }).finally(() => { exchangeInfoPromise = null; });
  }
  await exchangeInfoPromise;
  return exchangeInfoCache;
}

function makeMarkets(exchangeInfo, tickers) {
  const tickerMap = new Map(tickers.map(ticker => [ticker.symbol, ticker]));
  return exchangeInfo.symbols
    .filter(item => item.status === 'TRADING' && item.quoteAsset === 'USDT' && item.isSpotTradingAllowed !== false)
    .map(item => {
      const ticker = tickerMap.get(item.symbol) || {};
      const notional = item.filters?.find(filter => filter.filterType === 'NOTIONAL' || filter.filterType === 'MIN_NOTIONAL');
      return {
        symbol: item.symbol,
        baseAsset: item.baseAsset,
        quoteAsset: item.quoteAsset,
        price: Number(ticker.lastPrice) || 0,
        change: Number(ticker.priceChangePercent) || 0,
        quoteVolume: Number(ticker.quoteVolume) || 0,
        minNotional: Number(notional?.minNotional) || 0
      };
    })
    .sort((a, b) => b.quoteVolume - a.quoteVolume);
}

function validatedWatchlist(symbols, marketSet) {
  const requested = Array.isArray(symbols) ? symbols : WATCHLIST;
  return [...new Set(requested
    .filter(symbol => typeof symbol === 'string' && /^[A-Z0-9]{2,24}USDT$/.test(symbol) && marketSet.has(symbol)))]
    .slice(0, MAX_WATCHLIST);
}

function candleLimit(interval) { return interval === '1d' || interval === '1w' ? 180 : 240; }

ipcMain.handle('market:snapshot', async (_event, intervals, requestedSymbols) => {
  if (!Array.isArray(intervals) || intervals.length !== 2 || intervals.some(value => !INTERVALS.has(value))) {
    throw new Error('Unsupported timeframe selection.');
  }
  const [exchangeInfo, tickers] = await Promise.all([getExchangeInfo(), request('/api/v3/ticker/24hr')]);
  const marketSet = new Set(exchangeInfo.symbols.filter(item => item.status === 'TRADING' && item.quoteAsset === 'USDT' && item.isSpotTradingAllowed !== false).map(item => item.symbol));
  const symbols = validatedWatchlist(requestedSymbols, marketSet);
  const marketInfo = new Map(makeMarkets(exchangeInfo, tickers).map(market => [market.symbol, market]));
  const bySymbol = new Map(tickers.map(ticker => [ticker.symbol, ticker]));
  const jobs = symbols.flatMap(symbol => intervals.map(interval => ({ symbol, interval })));
  const candles = await mapLimit(jobs, 6, async ({ symbol, interval }) => {
    try {
      const rows = await request('/api/v3/klines', `?symbol=${symbol}&interval=${interval}&limit=${candleLimit(interval)}`);
      return { key: `${symbol}:${interval}`, rows };
    } catch (error) { return { key: `${symbol}:${interval}`, rows: null, error: error.message }; }
  });
  const responseSymbols = [...new Set([...symbols, 'BTCUSDT'])];
  return {
    source: 'Binance Spot public market data',
    fetchedAt: Date.now(),
    watchlist: symbols,
    tickers: responseSymbols.map(symbol => ({ ...marketInfo.get(symbol), ...bySymbol.get(symbol), symbol })).filter(item => item.lastPrice),
    candles: Object.fromEntries(candles.filter(item => item.rows).map(item => [item.key, item.rows]))
  };
});

ipcMain.handle('market:catalog', async (_event, forceRefresh = false) => {
  if (catalogCache && Date.now() - catalogCacheAt < 5 * 60 * 1000 && forceRefresh !== true) return catalogCache;
  const [exchangeInfo, tickers] = await Promise.all([getExchangeInfo(forceRefresh === true), request('/api/v3/ticker/24hr')]);
  const markets = makeMarkets(exchangeInfo, tickers);
  catalogCache = { source: 'Binance Spot', fetchedAt: Date.now(), markets };
  catalogCacheAt = Date.now();
  return catalogCache;
});

ipcMain.handle('market:scanner-snapshot', async (_event, intervals) => {
  if (!Array.isArray(intervals) || intervals.length !== 2 || intervals.some(value => !INTERVALS.has(value))) {
    throw new Error('Unsupported timeframe selection.');
  }
  const [exchangeInfo, tickers] = await Promise.all([getExchangeInfo(), request('/api/v3/ticker/24hr')]);
  const allMarkets = makeMarkets(exchangeInfo, tickers);
  const eligibleMarkets = allMarkets.filter(market => market.quoteVolume >= MIN_DAILY_QUOTE_VOLUME &&
    !STABLECOINS.has(market.baseAsset) && !/(UP|DOWN|BULL|BEAR)$/.test(market.baseAsset));
  const eligible = new Set(eligibleMarkets.map(market => market.symbol));
  const tickerMap = new Map(tickers.filter(ticker => eligible.has(ticker.symbol)).map(ticker => [ticker.symbol, ticker]));
  const jobs = eligibleMarkets.flatMap(market => intervals.map(interval => ({ symbol: market.symbol, interval })));
  const candles = await mapLimit(jobs, 4, async ({ symbol, interval }) => {
    try {
      const rows = await request('/api/v3/klines', `?symbol=${symbol}&interval=${interval}&limit=${candleLimit(interval)}`);
      return { key: `${symbol}:${interval}`, rows };
    } catch (error) { return { key: `${symbol}:${interval}`, rows: null, error: error.message }; }
  });
  const candleMap = Object.fromEntries(candles.filter(item => item.rows).map(item => [item.key, item.rows]));
  const symbolsWithCandles = new Set(eligibleMarkets.filter(market => intervals.every(interval => candleMap[`${market.symbol}:${interval}`])).map(market => market.symbol));
  return {
    source: 'Binance Spot public market data',
    fetchedAt: Date.now(),
    intervals,
    universeCount: allMarkets.length,
    eligibleCount: eligibleMarkets.length,
    scannedCount: symbolsWithCandles.size,
    failedCount: eligibleMarkets.length - symbolsWithCandles.size,
    liquidityFloor: MIN_DAILY_QUOTE_VOLUME,
    tickers: eligibleMarkets.map(market => ({ ...market, ...tickerMap.get(market.symbol) })),
    candles: candleMap,
  };
});

app.whenReady().then(() => {
  makeWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) makeWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
