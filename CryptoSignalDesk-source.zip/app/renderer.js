const INTERVALS = { short: ['15m', '1h'], swing: ['4h', '1d'], long: ['1d', '1w'] };
const DEFAULT_WATCHLIST = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT', 'LTCUSDT', 'DOTUSDT', 'BCHUSDT'];
const WATCHLIST_STORAGE_KEY = 'crypto-signal-desk.watchlist.v1';
const NAMES = { BTC: 'Bitcoin', ETH: 'Ethereum', SOL: 'Solana', BNB: 'BNB', XRP: 'XRP', ADA: 'Cardano', DOGE: 'Dogecoin', AVAX: 'Avalanche', LINK: 'Chainlink', LTC: 'Litecoin', DOT: 'Polkadot', BCH: 'Bitcoin Cash' };
function readWatchlist() {
  try {
    const saved = JSON.parse(localStorage.getItem(WATCHLIST_STORAGE_KEY) || 'null');
    if (Array.isArray(saved) && saved.length) {
      const valid = [...new Set(saved.filter(symbol => typeof symbol === 'string' && /^[A-Z0-9]{2,24}USDT$/.test(symbol)))].slice(0, 50);
      if (valid.length) return valid;
    }
  } catch {}
  return [...DEFAULT_WATCHLIST];
}
const state = { horizon: 'swing', watchlist: readWatchlist(), snapshot: null, analyses: new Map(), selected: 'BTCUSDT', loading: false, marketPending: false, lastGoodAt: null, page: 'overview', catalog: null, catalogPage: 1, catalogLoading: false, chartSymbol: null, chartInterval: null, scannerSnapshot: null, scannerAnalyses: [], scannerLoading: false, scannerFetchedAt: null };
const $ = id => document.getElementById(id);

function formatPrice(value) {
  if (!Number.isFinite(value)) return '—';
  const digits = value >= 1000 ? 2 : value >= 1 ? 3 : value >= .01 ? 4 : value >= .0001 ? 6 : value >= .000001 ? 8 : 10;
  return new Intl.NumberFormat('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(value);
}
function money(value, digits = 2) { return Number.isFinite(value) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: digits, maximumFractionDigits: digits }).format(value) : '—'; }
function moneyPrice(value) {
  if (!Number.isFinite(value)) return '—';
  const digits = value >= 1000 ? 2 : value >= 1 ? 3 : value >= .01 ? 4 : value >= .0001 ? 6 : value >= .000001 ? 8 : 10;
  return money(value, digits);
}
function pct(value) { return `${value >= 0 ? '+' : ''}${Number(value).toFixed(2)}%`; }
function pairName(symbol) { return `${symbol.replace('USDT', '')} / USDT`; }
function ema(values, period) {
  if (values.length < period) return values.map(() => NaN);
  const out = new Array(values.length).fill(NaN); let seed = values.slice(0, period).reduce((a,b) => a+b, 0) / period;
  out[period - 1] = seed; const alpha = 2 / (period + 1);
  for (let i = period; i < values.length; i++) out[i] = values[i] * alpha + out[i - 1] * (1 - alpha);
  return out;
}
function rsi(values, period = 14) {
  if (values.length <= period) return NaN;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) { const change = values[i] - values[i - 1]; gain += Math.max(0, change); loss += Math.max(0, -change); }
  let avgGain = gain / period, avgLoss = loss / period;
  for (let i = period + 1; i < values.length; i++) { const change = values[i] - values[i - 1]; avgGain = (avgGain * (period - 1) + Math.max(0, change)) / period; avgLoss = (avgLoss * (period - 1) + Math.max(0, -change)) / period; }
  return avgLoss === 0 ? 100 : 100 - (100 / (1 + avgGain / avgLoss));
}
function indicators(rows) {
  const candles = rows.map(row => ({ time: Number(row[0]), open: +row[1], high: +row[2], low: +row[3], close: +row[4], volume: +row[5] }));
  const closes = candles.map(c => c.close); const ema20 = ema(closes, 20), ema50 = ema(closes, 50);
  const fast = ema(closes, 12), slow = ema(closes, 26); const macd = fast.map((v,i) => Number.isFinite(v) && Number.isFinite(slow[i]) ? v - slow[i] : NaN); const macdValues = macd.filter(Number.isFinite); const signal = ema(macdValues, 9);
  const histSeries = macdValues.map((value,i) => value - signal[i]);
  const hist = histSeries.at(-1);
  const tr = candles.map((c,i) => i === 0 ? c.high - c.low : Math.max(c.high - c.low, Math.abs(c.high - candles[i-1].close), Math.abs(c.low - candles[i-1].close)));
  const atr = tr.slice(-14).reduce((a,b) => a+b, 0) / Math.min(14, tr.length);
  const volumes = candles.slice(-21, -1).map(c => c.volume); const averageVolume = volumes.length ? volumes.reduce((a,b) => a+b,0) / volumes.length : 0;
  return { candles, closes, ema20, ema50, rsi: rsi(closes), macdHist: hist, previousMacdHist: histSeries.at(-2), atr, averageVolume, currentVolume: candles.at(-1)?.volume || 0 };
}
function support(ind, direction) {
  const i = ind.closes.length - 1; const isLong = direction === 'LONG';
  const emaTrend = isLong ? ind.ema20[i] > ind.ema50[i] : ind.ema20[i] < ind.ema50[i];
  const priceSide = isLong ? ind.closes[i] > ind.ema20[i] : ind.closes[i] < ind.ema20[i];
  const macdSide = isLong ? ind.macdHist > 0 : ind.macdHist < 0;
  const rsiOk = isLong ? (ind.rsi >= 50 && ind.rsi <= 70) : (ind.rsi >= 30 && ind.rsi <= 50);
  const rsiSoft = isLong ? (ind.rsi >= 45 && ind.rsi <= 75) : (ind.rsi >= 25 && ind.rsi <= 55);
  let score = 0;
  score += emaTrend ? 24 : 0;
  score += priceSide ? 20 : 0;
  score += macdSide ? 20 : 0;
  score += rsiOk ? 18 : rsiSoft ? 9 : 0;
  score += ind.currentVolume >= ind.averageVolume ? 10 : 5;
  const candle = ind.candles.at(-1); score += (isLong ? candle.close >= candle.open : candle.close <= candle.open) ? 8 : 0;
  return { score, emaTrend, priceSide, macdSide, rsiOk, rsiSoft };
}
function makeLevels(price, atr, direction = 'LONG') {
  const stopDistance = Math.max((Number(atr) || 0) * 1.5, price * .004);
  return { entry: price, stop: direction === 'LONG' ? price - stopDistance : price + stopDistance, target: direction === 'LONG' ? price + stopDistance * 2 : price - stopDistance * 2, stopDistance };
}
function analyze(symbol, ticker, snapshot = state.snapshot, horizon = state.horizon) {
  const [triggerInterval, confirmInterval] = INTERVALS[horizon];
  const triggerRows = snapshot?.candles?.[`${symbol}:${triggerInterval}`];
  const confirmRows = snapshot?.candles?.[`${symbol}:${confirmInterval}`];
  if (!triggerRows?.length || !confirmRows?.length) return null;
  const trigger = indicators(triggerRows), confirm = indicators(confirmRows);
  const price = +ticker.lastPrice; const change = +ticker.priceChangePercent;
  const longT = support(trigger, 'LONG'), longC = support(confirm, 'LONG');
  const shortT = support(trigger, 'SHORT'), shortC = support(confirm, 'SHORT');
  const longScore = Math.round(longT.score * .65 + longC.score * .35);
  const shortScore = Math.round(shortT.score * .65 + shortC.score * .35);
  const stopValid = price > 0 && Math.max(trigger.atr * 1.5, price * .004) < price * .8;
  let direction = null, score = Math.max(longScore, shortScore), confirmSupport;
  if (longScore >= shortScore) confirmSupport = { trigger: longT, confirm: longC };
  else confirmSupport = { trigger: shortT, confirm: shortC };
  if (stopValid && longScore >= 72 && longT.emaTrend && longT.priceSide && longT.macdSide && longC.emaTrend && longC.macdSide && trigger.rsi >= 45 && trigger.rsi <= 75) direction = 'LONG';
  else if (stopValid && shortScore >= 72 && shortT.emaTrend && shortT.priceSide && shortT.macdSide && shortC.emaTrend && shortC.macdSide && trigger.rsi >= 25 && trigger.rsi <= 55) direction = 'SHORT';
  if (direction) score = direction === 'LONG' ? longScore : shortScore;
  const atr = trigger.atr;
  const levels = direction ? makeLevels(price, atr, direction) : null;
  const reasons = [];
  if (direction) {
    reasons.push(`${triggerInterval} EMA 20 / 50 trend is ${direction === 'LONG' ? 'bullish' : 'bearish'}.`);
    reasons.push(`${confirmInterval} timeframe confirms the same EMA trend and MACD momentum.`);
    reasons.push(`Trigger RSI is ${trigger.rsi.toFixed(1)}; within the ${direction === 'LONG' ? '45–75 long' : '25–55 short'} filter.`);
    reasons.push(`ATR(14) on ${triggerInterval} is ${formatPrice(atr)}; sample stop distance is 1.5× ATR.`);
  } else {
    reasons.push('Trend, momentum, and higher-timeframe confirmation do not all align.');
    reasons.push(`Highest directional confluence is ${score}/100; a setup needs 72 and aligned trend filters.`);
    if (trigger.rsi > 75 || trigger.rsi < 25) reasons.push(`Trigger RSI at ${trigger.rsi.toFixed(1)} is stretched; wait for a reset.`);
    else reasons.push(`Trigger RSI is ${trigger.rsi.toFixed(1)}; indicator readings can reverse quickly.`);
    reasons.push(`No entry, stop, or target is shown until the setup rules align.`);
  }
  return { symbol, price, change, direction, score, longScore, shortScore, triggerInterval, confirmInterval, trigger, confirm, levels, reasons, dataTime: Number(triggerRows.at(-1)[6]) || Number(triggerRows.at(-1)[0]), confluence: confirmSupport, quoteVolume: Number(ticker.quoteVolume) || 0, minNotional: Number(ticker.minNotional) || 0 };
}

function lowerBollingerBand(closes) {
  if (closes.length < 20) return NaN;
  const values = closes.slice(-20), mean = values.reduce((sum,value) => sum + value, 0) / values.length;
  const variance = values.reduce((sum,value) => sum + (value - mean) ** 2, 0) / values.length;
  return mean - 2 * Math.sqrt(variance);
}

function evaluateBuy(analysis) {
  const { trigger: t, confirm: c, price } = analysis;
  const current = t.candles.at(-1), previous = t.candles.at(-2);
  if (!current || !previous || !Number.isFinite(t.rsi) || !Number.isFinite(t.atr) || !price || Math.max(t.atr * 1.5, price * .004) >= price * .8) return null;
  const longT = support(t, 'LONG'), longC = support(c, 'LONG');
  const volumeRatio = t.averageVolume > 0 ? t.currentVolume / t.averageVolume : 0;
  const strategies = [];
  if (analysis.longScore >= 72 && longT.emaTrend && longT.priceSide && longT.macdSide && longC.emaTrend && longC.macdSide && t.rsi >= 45 && t.rsi <= 75) {
    strategies.push({ name: 'Trend', score: analysis.longScore, reason: 'Price is above its short and medium trend lines, momentum is positive, and the higher timeframe agrees.' });
  }
  const priorCandles = t.candles.slice(-21, -1);
  const priorHigh = priorCandles.length ? Math.max(...priorCandles.map(candle => candle.high)) : NaN;
  if (current.close > priorHigh && volumeRatio >= 1.25 && longT.emaTrend && longC.emaTrend && longC.macdSide && t.rsi >= 50 && t.rsi <= 78) {
    strategies.push({ name: 'Breakout', score: Math.min(98, Math.max(76, Math.round(76 + Math.min(18, (volumeRatio - 1.25) * 12)))), reason: `Price cleared the previous 20-candle high and volume is ${volumeRatio.toFixed(1)}× its recent average, with the higher timeframe trending up.` });
  }
  if (longC.emaTrend && longT.priceSide && t.rsi >= 38 && t.rsi <= 58 && current.close > current.open && t.macdHist >= t.previousMacdHist) {
    strategies.push({ name: 'Trend pullback', score: Math.min(95, Math.max(75, Math.round(75 + (longC.score - 70) * .3))), reason: 'The higher-timeframe trend is rising; price has recovered above its short trend line and momentum is improving after a pullback.' });
  }
  const previousLower = lowerBollingerBand(t.closes.slice(0, -1));
  const currentLower = lowerBollingerBand(t.closes);
  if (longC.emaTrend && t.rsi >= 28 && t.rsi <= 43 && previous.close < previousLower && current.close > currentLower && current.close > current.open) {
    strategies.push({ name: 'Mean-reversion rebound', score: Math.min(92, Math.max(74, Math.round(74 + (longC.score - 65) * .25))), reason: 'Price has rebounded above its recent volatility band after a weak reading; the longer trend is still rising.' });
  }
  if (!strategies.length) return null;
  strategies.sort((a,b) => b.score - a.score);
  const selected = strategies[0];
  return { ...analysis, direction: 'LONG', score: selected.score, strategy: selected.name, strategyReason: selected.reason, matchedStrategies: strategies.map(item => item.name), levels: makeLevels(price, t.atr, 'LONG'), reasons: [selected.reason, `${analysis.triggerInterval} trigger with ${analysis.confirmInterval} higher-timeframe confirmation.`, `ATR(14) is ${formatPrice(t.atr)}; the example stop is 1.5× ATR and the target is 2R.`] };
}

function buildAnalyses() {
  state.analyses.clear();
  for (const ticker of state.snapshot?.tickers || []) {
    if (!state.watchlist.includes(ticker.symbol)) continue;
    const result = analyze(ticker.symbol, ticker); if (result) state.analyses.set(ticker.symbol, result);
  }
}
function renderSummary() {
  const allTickers = state.snapshot?.tickers || [];
  const tickers = allTickers.filter(ticker => state.watchlist.includes(ticker.symbol));
  const btc = allTickers.find(t => t.symbol === 'BTCUSDT');
  if (btc) { $('btcPrice').textContent = money(+btc.lastPrice, 2); $('btcChange').textContent = pct(+btc.priceChangePercent); $('btcChange').classList.toggle('negative', +btc.priceChangePercent < 0); }
  const positive = tickers.filter(t => +t.priceChangePercent > 0).length;
  $('breadthValue').textContent = `${positive} / ${tickers.length || state.watchlist.length}`;
  $('breadthDetail').textContent = positive > tickers.length / 2 ? 'More tracked assets up over 24h' : 'More tracked assets down over 24h';
  $('setupCount').textContent = [...state.analyses.values()].filter(a => a.direction).length.toString().padStart(2, '0');
  $('setupCount').nextElementSibling.querySelector('.muted').textContent = `From ${state.analyses.size} watchlist markets`;
  $('watchlistCount').textContent = state.watchlist.length;
  $('watchlistFootnote').textContent = `${state.watchlist.length} selected Binance USDT market${state.watchlist.length === 1 ? '' : 's'} monitored`;
  const time = state.lastGoodAt ? new Date(state.lastGoodAt) : null;
  $('updatedAt').textContent = time ? time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
  const stale = !time || Date.now() - time.getTime() > 4 * 60 * 1000;
  $('marketStatus').textContent = stale ? 'Market data stale' : 'Market connected';
  $('connectionLabel').textContent = stale ? 'Data needs refresh' : 'Connection healthy';
  $('connectionMessage').textContent = stale ? 'Last market snapshot may be out of date' : `Updated ${time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · public spot feed`;
  document.querySelectorAll('.pulse-dot').forEach(dot => dot.classList.toggle('offline', stale));
  $('freshTag').innerHTML = stale ? '<i></i> Stale' : '<i></i> Live';
  $('page-date')?.replaceChildren();
  const date = new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date()).toUpperCase();
  document.querySelector('.eyebrow').childNodes[0].textContent = date + ' ';
  $('buyHorizon').value = state.horizon;
}
function renderTable() {
  const tbody = $('marketRows'); const analyses = [...state.analyses.values()].sort((a,b) => Number(Boolean(b.direction)) - Number(Boolean(a.direction)) || b.score - a.score);
  if (!analyses.length) { tbody.innerHTML = '<tr><td colspan="5" class="empty-row">Candle data is not available. Check the connection and refresh.</td></tr>'; return; }
  tbody.innerHTML = analyses.map(a => {
    const base = a.symbol.replace('USDT',''); const bias = a.direction || 'WAIT'; const cls = a.direction === 'LONG' ? 'long' : a.direction === 'SHORT' ? 'short' : 'wait';
    return `<tr data-symbol="${a.symbol}" class="${a.symbol === state.selected ? 'selected' : ''}"><td><div class="asset-cell"><span class="coin-badge">${base.slice(0,2)}</span><span class="asset-name"><b>${base}</b><small>${NAMES[base] || base}</small></span></div></td><td class="price-cell">$${formatPrice(a.price)}</td><td class="${a.change >= 0 ? 'change-up' : 'change-down'}">${pct(a.change)}</td><td><span class="bias-chip ${cls}"><i class="dot ${a.direction === 'LONG' ? 'bullish' : a.direction === 'SHORT' ? 'bearish' : 'neutral'}"></i>${bias}</span></td><td><div class="confluence"><span class="mini-bar ${a.score < 55 ? 'low' : ''}"><i class="score-${Math.round(a.score / 10) * 10}"></i></span><b>${a.score}</b></div></td></tr>`;
  }).join('');
  tbody.querySelectorAll('tr[data-symbol]').forEach(row => row.addEventListener('click', () => { state.selected = row.dataset.symbol; renderTable(); renderSelected(); }));
}
function renderSelected() {
  const a = state.analyses.get(state.selected) || state.analyses.values().next().value;
  if (!a) return;
  state.selected = a.symbol;
  const direction = a.direction;
  $('selectedPair').textContent = pairName(a.symbol); $('chartPair').textContent = pairName(a.symbol);
  $('selectedPrice').textContent = moneyPrice(a.price); $('chartPrice').textContent = moneyPrice(a.price);
  $('selectedChange').textContent = pct(a.change); $('selectedChange').className = a.change >= 0 ? 'change-up' : 'change-down';
  $('planHorizon').textContent = state.horizon === 'short' ? 'SHORT TERM · 15M / 1H' : state.horizon === 'long' ? 'LONG TERM · 1D / 1W' : 'SWING · 4H / 1D';
  $('chartInterval').textContent = `${a.triggerInterval} candles · recent history`;
  const banner = $('signalBanner'); banner.className = `signal-banner ${direction === 'LONG' ? 'long' : direction === 'SHORT' ? 'short' : 'wait'}`;
  $('signalMark').textContent = direction === 'LONG' ? '↗' : direction === 'SHORT' ? '↘' : '−';
  $('signalTitle').textContent = direction ? `${direction} setup detected` : 'WAIT · no aligned setup';
  $('signalSubtitle').textContent = direction ? (direction === 'LONG' ? 'Potential long idea · review before any action' : 'Hypothetical short idea · derivatives risks apply') : 'Stay selective until the rules align';
  $('scorePill').textContent = `${a.score} / 100`;
  $('entryLevel').textContent = a.levels ? `$${formatPrice(a.levels.entry)}` : '—';
  $('stopLevel').textContent = a.levels ? `$${formatPrice(a.levels.stop)}` : '—';
  $('targetLevel').textContent = a.levels ? `$${formatPrice(a.levels.target)}` : '—';
  $('entryHint').textContent = a.levels ? 'Latest market price · not a limit order' : 'No actionable entry';
  $('stopHint').textContent = a.levels ? `${direction === 'LONG' ? '−' : '+'}${((a.levels.stopDistance / a.price) * 100).toFixed(2)}% from entry` : 'Shown when a setup aligns';
  $('targetHint').textContent = a.levels ? `${direction === 'LONG' ? '+' : '−'}${((a.levels.stopDistance * 2 / a.price) * 100).toFixed(2)}% · 2R` : 'Shown when a setup aligns';
  $('rrValue').textContent = a.levels ? '1 : 2.0' : '—';
  $('reasonCount').textContent = `${a.reasons.length} checks`;
  $('reasonList').innerHTML = a.reasons.map((r,i) => `<li class="${!direction && i === 1 ? 'caution' : ''}">${r}</li>`).join('');
  $('signalDisclaimer').textContent = direction === 'SHORT' ? 'Short ideas are hypothetical. Derivatives can lose more quickly and may be liquidated; leverage and funding are not modeled.' : 'Analysis only. Stop orders may fill at a worse price; fees, slippage, and sudden gaps are not modeled.';
  renderChart(a);
  updateSizing();
}

function volumeLabel(value) {
  if (!Number.isFinite(value) || value <= 0) return '—';
  if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `$${(value / 1e3).toFixed(0)}K`;
  return money(value, 0);
}
function filteredCatalog() {
  const query = $('marketSearch').value.trim().toLowerCase();
  if (!query) return state.catalog || [];
  return (state.catalog || []).filter(item => `${item.baseAsset} ${item.symbol} ${NAMES[item.baseAsset] || ''}`.toLowerCase().includes(query));
}
function renderCatalog() {
  const list = filteredCatalog(), pageSize = 50, pages = Math.max(1, Math.ceil(list.length / pageSize));
  state.catalogPage = Math.min(state.catalogPage, pages);
  const start = (state.catalogPage - 1) * pageSize;
  $('catalogCount').textContent = `${list.length.toLocaleString()} market${list.length === 1 ? '' : 's'}${$('marketSearch').value.trim() ? ' found' : ' available'}`;
  $('catalogUpdated').textContent = state.catalogFetchedAt ? `Updated ${new Date(state.catalogFetchedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : '';
  $('catalogPageLabel').textContent = `Page ${state.catalogPage} of ${pages}`;
  $('catalogPrev').disabled = state.catalogPage <= 1; $('catalogNext').disabled = state.catalogPage >= pages;
  const tbody = $('catalogRows');
  if (!list.length) { tbody.innerHTML = '<tr><td colspan="5" class="empty-row">No matching USDT markets found.</td></tr>'; return; }
  tbody.innerHTML = list.slice(start, start + pageSize).map(item => `<tr data-catalog-symbol="${item.symbol}"><td><div class="asset-cell"><span class="coin-badge">${item.baseAsset.slice(0,2)}</span><span class="asset-name"><b>${item.baseAsset}</b><small>${NAMES[item.baseAsset] || item.baseAsset} · ${item.symbol}</small></span></div></td><td class="price-cell">$${formatPrice(item.price)}</td><td class="${item.change >= 0 ? 'change-up' : 'change-down'}">${pct(item.change)}</td><td class="volume-cell">${volumeLabel(item.quoteVolume)}</td><td><button class="chart-link" data-open-symbol="${item.symbol}">Open chart ↗</button></td></tr>`).join('');
  tbody.querySelectorAll('[data-open-symbol]').forEach(button => button.addEventListener('click', event => {
    event.stopPropagation(); const symbol = button.dataset.openSymbol;
    $('tvSymbolInput').value = `BINANCE:${symbol}`; state.chartSymbol = null; showPage('charts');
  }));
}
async function loadCatalog(force = false) {
  if (state.catalogLoading) return;
  if (!force && state.catalog && Date.now() - state.catalogFetchedAt < 5 * 60 * 1000) { renderCatalog(); return; }
  state.catalogLoading = true; $('catalogRows').innerHTML = '<tr><td colspan="5" class="empty-row"><span class="loader"></span>Loading exchange market list…</td></tr>';
  try {
    const result = await window.marketAPI.getCatalog(force); state.catalog = result.markets; state.catalogFetchedAt = result.fetchedAt; state.catalogPage = 1; renderCatalog();
  } catch (error) {
    $('catalogRows').innerHTML = `<tr><td colspan="5" class="empty-row">Could not load the Binance market list. ${error?.message || ''}</td></tr>`;
    $('catalogCount').textContent = 'Market list unavailable';
  } finally { state.catalogLoading = false; }
}
function renderWatchlistEditor() {
  const options = $('watchlistMarketOptions');
  options.innerHTML = (state.catalog || []).map(item => `<option value="${item.symbol}">${item.baseAsset} · ${NAMES[item.baseAsset] || item.baseAsset}</option>`).join('');
  const list = $('watchlistEditItems');
  list.innerHTML = state.watchlist.map(symbol => {
    const base = symbol.replace('USDT', '');
    return `<li><span><b>${base}</b><small>${NAMES[base] || base} · ${symbol}</small></span><button class="watchlist-remove" data-remove-watch="${symbol}" aria-label="Remove ${base}" title="Remove ${base}">×</button></li>`;
  }).join('');
  list.querySelectorAll('[data-remove-watch]').forEach(button => button.addEventListener('click', () => {
    state.watchlist = state.watchlist.filter(symbol => symbol !== button.dataset.removeWatch);
    saveWatchlist();
  }));
}
function saveWatchlist() {
  if (!state.watchlist.length) state.watchlist = ['BTCUSDT'];
  try { localStorage.setItem(WATCHLIST_STORAGE_KEY, JSON.stringify(state.watchlist)); }
  catch { toast('Could not save the watchlist on this PC.'); }
  if (!state.watchlist.includes(state.selected)) state.selected = state.watchlist[0];
  state.analyses.clear(); renderWatchlistEditor(); renderSummary(); renderTable();
  refreshMarket(true);
}
async function openWatchlistEditor() {
  if (!state.catalog || Date.now() - state.catalogFetchedAt > 5 * 60 * 1000) await loadCatalog();
  renderWatchlistEditor();
  $('watchlistDialog').showModal();
}
function addWatchlistCoin() {
  let symbol = $('watchlistSymbolInput').value.trim().toUpperCase().replace(/[\s/_-]/g, '');
  if (symbol && !symbol.endsWith('USDT')) symbol += 'USDT';
  if (!state.catalog?.some(item => item.symbol === symbol)) { toast('Choose a currently tradable Binance USDT pair.'); return; }
  if (state.watchlist.includes(symbol)) { toast('That coin is already on your watchlist.'); return; }
  if (state.watchlist.length >= 50) { toast('The personal watchlist can hold up to 50 coins.'); return; }
  state.watchlist.push(symbol); $('watchlistSymbolInput').value = ''; saveWatchlist();
}
function bindBuyChartButtons(container) {
  container.querySelectorAll('[data-buy-chart]').forEach(button => button.addEventListener('click', () => {
    $('tvSymbolInput').value = `BINANCE:${button.dataset.buyChart}`; state.chartSymbol = null; showPage('charts');
  }));
}
function plannedPosition(a) {
  const budget = Math.max(0, Number($('accountValue').value) || 0);
  const riskPct = Math.max(0, Math.min(5, Number($('riskPercent').value) || 0));
  const stopFraction = a?.levels && a.price > 0 ? a.levels.stopDistance / a.price : 0;
  const maxLoss = budget * riskPct / 100;
  const value = stopFraction > 0 ? Math.min(budget, maxLoss / stopFraction) : 0;
  return { value, lossAtStop: value * stopFraction, budget, minimum: Number(a?.minNotional) || 0 };
}
function buyCard(a, index) {
  const base = a.symbol.replace('USDT', ''), plan = plannedPosition(a), units = plan.value / a.price;
  const sizeNote = plan.minimum && plan.value < plan.minimum
    ? `Size is below this pair’s current ${money(plan.minimum, 2)} minimum order; skip unless your budget covers it.`
    : 'Estimated amount at risk if the example stop fills. Fees and slippage are excluded.';
  return `<article class="panel buy-card confirmed-buy"><div class="buy-card-head"><span class="rank-tag">#${index + 1} · ${a.strategy.toUpperCase()}</span><span class="buy-score">${a.score}<small>/100</small></span></div><div class="buy-asset"><span class="coin-badge">${base.slice(0,2)}</span><div><h2>${base} <small>/ USDT</small></h2><p>${NAMES[base] || base} · ${a.triggerInterval} / ${a.confirmInterval} · 24h volume ${volumeLabel(a.quoteVolume)}</p></div></div><div class="buy-price">${moneyPrice(a.price)} <span class="${a.change >= 0 ? 'change-up' : 'change-down'}">${pct(a.change)} <small>24h</small></span></div><div class="buy-level-grid"><div><span>ENTRY REFERENCE</span><b>${moneyPrice(a.levels.entry)}</b></div><div><span>STOP LOSS</span><b class="stop-text">${moneyPrice(a.levels.stop)}</b></div><div><span>TAKE PROFIT · 2R</span><b class="target-text">${moneyPrice(a.levels.target)}</b></div></div><div class="buy-rationale"><b>Why it may fit:</b> ${a.strategyReason}</div><div class="position-estimate"><div><span>POSITION VALUE</span><b>${money(plan.value,2)}</b></div><div><span>EST. UNITS</span><b>${new Intl.NumberFormat('en-US',{maximumSignificantDigits:6}).format(units)} ${base}</b></div><div><span>LOSS AT STOP</span><b class="stop-text">${money(plan.lossAtStop,2)}</b></div></div><button class="primary-button buy-chart-button" data-buy-chart="${a.symbol}">Open chart &amp; review setup ↗</button><p class="buy-card-foot">${sizeNote} Rule-based estimate, not a probability of profit or a trade instruction.</p></article>`;
}
function waitCandidateCard(a, index) {
  const base = a.symbol.replace('USDT', ''), t = support(a.trigger, 'LONG'), c = support(a.confirm, 'LONG');
  const checks = [
    { ok: t.emaTrend, label: `${a.triggerInterval} trend rising` },
    { ok: t.priceSide, label: 'Price above the short trend line' },
    { ok: t.macdSide, label: 'Momentum positive' },
    { ok: c.emaTrend && c.macdSide, label: `${a.confirmInterval} trend confirms` },
    { ok: a.trigger.rsi >= 45 && a.trigger.rsi <= 75, label: `RSI in range (${a.trigger.rsi.toFixed(1)})` },
    { ok: a.longScore >= 72, label: 'Confluence reaches 72/100' }
  ];
  const met = checks.filter(item => item.ok).length;
  return `<article class="panel buy-card wait-candidate"><div class="buy-card-head"><span class="rank-tag wait-rank">#${index + 1} · CLOSEST MATCH</span><span class="wait-pill">WAIT</span></div><div class="buy-asset"><span class="coin-badge">${base.slice(0,2)}</span><div><h2>${base} <small>/ USDT</small></h2><p>${NAMES[base] || base} · ${a.triggerInterval} / ${a.confirmInterval}</p></div></div><div class="buy-price">${moneyPrice(a.price)} <span class="${a.change >= 0 ? 'change-up' : 'change-down'}">${pct(a.change)} <small>24h</small></span></div><div class="watch-score-row"><span>LONG-SIDE CONFLUENCE</span><b>${a.longScore}<small>/100</small></b></div><div class="watch-meter"><i class="score-${Math.round(a.longScore / 10) * 10}"></i></div><div class="watch-checks"><div class="reasons-heading">TREND CHECKLIST <span>${met}/${checks.length} passing</span></div><ul>${checks.map(item => `<li class="${item.ok ? 'check-pass' : 'check-miss'}"><i>${item.ok ? '✓' : '·'}</i>${item.label}</li>`).join('')}</ul></div><button class="secondary-button buy-chart-button" data-buy-chart="${a.symbol}">Open chart to monitor ↗</button><p class="buy-card-foot">No trade levels or position size: no buy strategy passed.</p></article>`;
}
function renderBestBuys() {
  const container = $('bestBuyCards'), snapshot = state.scannerSnapshot;
  if (!snapshot) {
    container.innerHTML = `<article class="panel best-buy-empty"><div class="no-buy-icon">◷</div><div class="section-kicker">MARKET SCAN ${state.scannerLoading ? 'RUNNING' : 'NOT READY'}</div><h2>${state.scannerLoading ? 'Scanning liquid USDT markets' : 'Waiting for a market scan'}</h2><p>${state.scannerLoading ? 'The scanner checks market data independently from your personal watchlist.' : 'Refresh to start a new market-wide scan.'}</p><button class="secondary-button" data-refresh-buy>Scan all markets</button></article>`;
    container.querySelector('[data-refresh-buy]')?.addEventListener('click', () => refreshBuyScan(true)); return;
  }
  const buys = state.scannerAnalyses.map(evaluateBuy).filter(Boolean).sort((a,b) => b.score - a.score || b.quoteVolume - a.quoteVolume);
  const analyzed = state.scannerAnalyses.length;
  const scanTime = state.scannerFetchedAt ? new Date(state.scannerFetchedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
  $('scannerStatus').textContent = `${snapshot.scannedCount.toLocaleString()} of ${snapshot.eligibleCount.toLocaleString()} liquid USDT markets scanned · ${snapshot.universeCount.toLocaleString()} active USDT markets total · updated ${scanTime}${snapshot.failedCount ? ` · ${snapshot.failedCount} with candle data unavailable` : ''}`;
  if (buys.length) {
    container.innerHTML = buys.map(buyCard).join('');
    bindBuyChartButtons(container); return;
  }
  if (!analyzed) {
    container.innerHTML = '<article class="panel best-buy-empty"><div class="no-buy-icon">◷</div><div class="section-kicker">MARKET DATA UNAVAILABLE</div><h2>No candles could be analyzed</h2><p>The scanner may be rate-limited or temporarily offline. Try again after a short wait.</p><button class="secondary-button" data-refresh-buy>Retry scan</button></article>';
    container.querySelector('[data-refresh-buy]')?.addEventListener('click', () => refreshBuyScan(true)); return;
  }
  const candidates = [...state.scannerAnalyses].sort((a,b) => b.longScore - a.longScore || b.quoteVolume - a.quoteVolume).slice(0,6);
  const cards = candidates.map(waitCandidateCard).join('');
  container.innerHTML = `<article class="panel watch-summary"><div class="no-buy-icon">⌁</div><div><div class="section-kicker">NO CONFIRMED BUY SETUP</div><h2>Nothing meets a buy strategy right now</h2><p>The scan checked ${analyzed.toLocaleString()} liquid markets using trend, breakout, pullback, and reversal rules. These are the closest long-side matches, ranked for monitoring only. WAIT is not a buy signal.</p></div></article>${cards}`;
  bindBuyChartButtons(container);
}
async function refreshBuyScan(showToast = false) {
  if (state.scannerLoading) { state.scannerPending = true; return; }
  state.scannerLoading = true; state.scannerPending = false;
  const horizon = state.horizon;
  $('buyScanRefresh').classList.add('spinning'); $('scannerStatus').textContent = 'Scanning liquid Binance Spot USDT markets…';
  renderBestBuys();
  $('scannerStatus').textContent = state.scannerSnapshot ? 'Refreshing market-wide data · the previous scan remains visible.' : 'Scanning all liquid Binance Spot USDT markets…';
  try {
    const snapshot = await window.marketAPI.getScannerSnapshot(INTERVALS[horizon]);
    if (horizon !== state.horizon) { state.scannerPending = true; return; }
    state.scannerSnapshot = snapshot; state.scannerFetchedAt = snapshot.fetchedAt; state.scannerHorizon = horizon;
    state.scannerAnalyses = [];
    for (const ticker of snapshot.tickers || []) {
      const result = analyze(ticker.symbol, ticker, snapshot, horizon);
      if (result) state.scannerAnalyses.push(result);
    }
    renderBestBuys();
    if (showToast) toast('Market-wide scan updated.');
  } catch (error) {
    $('scannerStatus').textContent = `Market scan unavailable · ${error?.message || 'Check your internet connection.'}`;
    if (!state.scannerSnapshot) {
      const failedContainer = $('bestBuyCards');
      failedContainer.innerHTML = '<article class="panel best-buy-empty"><div class="no-buy-icon">!</div><div class="section-kicker">MARKET SCAN UNAVAILABLE</div><h2>Could not complete the market-wide scan</h2><p>Check your connection or wait briefly before retrying if the market-data source is rate-limiting requests.</p><button class="secondary-button" data-refresh-buy>Retry scan</button></article>';
      failedContainer.querySelector('[data-refresh-buy]')?.addEventListener('click', () => refreshBuyScan(true));
    }
    if (showToast) toast('Could not refresh the market-wide scan.');
  } finally {
    state.scannerLoading = false; $('buyScanRefresh').classList.remove('spinning');
    if (state.scannerPending) { state.scannerPending = false; refreshBuyScan(); }
  }
}
function showPage(page) {
  state.page = page;
  document.querySelectorAll('.view-page').forEach(view => view.classList.toggle('active', view.id === `view-${page}`));
  document.querySelectorAll('.nav-item[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === page));
  const names = { overview: 'Overview', markets: 'All markets', charts: 'Charts', buys: 'Best buys now' };
  document.querySelector('.crumb b').textContent = names[page] || 'Overview';
  if (page === 'markets') loadCatalog();
  if (page === 'charts') renderTradingViewChart();
  if (page === 'buys') { renderBestBuys(); if (!state.scannerSnapshot || Date.now() - state.scannerFetchedAt > 5 * 60 * 1000) refreshBuyScan(); }
}
function renderTradingViewChart(force = false) {
  if (state.page !== 'charts') return;
  const symbol = $('tvSymbolInput').value.trim().toUpperCase();
  const interval = $('tvInterval').value;
  if (!/^[A-Z0-9._:-]{2,48}$/.test(symbol)) { toast('Enter a valid TradingView market symbol, such as BINANCE:ETHUSDT.'); return; }
  const frame = $('tvChartFrame');
  if (!force && state.chartSymbol === symbol && state.chartInterval === interval && frame.querySelector('.tradingview-widget-container')) return;
  frame.replaceChildren();
  const container = document.createElement('div'); container.className = 'tradingview-widget-container';
  const widget = document.createElement('div'); widget.className = 'tradingview-widget-container__widget';
  const credit = document.createElement('div'); credit.className = 'tv-widget-credit';
  const link = document.createElement('a'); link.href = `https://www.tradingview.com/symbols/${encodeURIComponent(symbol.replace(':','-'))}/`; link.textContent = `${symbol} chart`;
  link.target = '_blank'; link.rel = 'noreferrer'; credit.append(link, document.createTextNode(' · charts by TradingView'));
  const script = document.createElement('script'); script.type = 'text/javascript'; script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js'; script.async = true;
  script.textContent = JSON.stringify({ autosize: true, symbol, interval, timezone: 'Europe/Brussels', theme: 'dark', style: '1', locale: 'en', allow_symbol_change: true, calendar: false, details: true, hide_side_toolbar: false, hide_top_toolbar: false, hide_legend: false, hide_volume: false, hotlist: false, save_image: true, studies: ['STD;EMA', 'STD;RSI'], support_host: 'https://www.tradingview.com' });
  script.onerror = () => { frame.innerHTML = '<div class="tv-error">TradingView could not load. Check your connection, then choose Open again.</div>'; state.chartSymbol = null; };
  container.append(widget, credit, script); frame.append(container);
  state.chartSymbol = symbol; state.chartInterval = interval;
}
function renderChart(a) {
  const canvas = $('priceChart'), ctx = canvas.getContext('2d'), rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1; canvas.width = Math.max(1, Math.floor(rect.width * dpr)); canvas.height = Math.max(1, Math.floor(rect.height * dpr));
  ctx.setTransform(dpr,0,0,dpr,0,0); const w = rect.width, h = rect.height;
  ctx.clearRect(0,0,w,h);
  const candles = a.trigger.candles.slice(-96); const closes = candles.map(c => c.close); const line = ema(closes,20);
  if (closes.length < 2) { $('chartEmpty').style.display = 'grid'; return; }
  $('chartEmpty').style.display = 'none';
  const all = closes.concat(line.filter(Number.isFinite)); const min = Math.min(...all), max = Math.max(...all); const pad = (max-min)*.14 || max*.01;
  const lo=min-pad, hi=max+pad, xAt=i=>8+i*(w-16)/(closes.length-1), yAt=v=>h-7-(v-lo)/(hi-lo)*(h-18);
  ctx.strokeStyle='#1b2a36';ctx.lineWidth=1;
  for(let i=0;i<4;i++){const y=8+i*(h-16)/3;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  ctx.beginPath();closes.forEach((v,i)=>{i?ctx.lineTo(xAt(i),yAt(v)):ctx.moveTo(xAt(i),yAt(v));});
  ctx.lineWidth=1.6;ctx.strokeStyle='#55d8aa';ctx.stroke();
  ctx.lineTo(xAt(closes.length-1),h);ctx.lineTo(xAt(0),h);ctx.closePath();const grad=ctx.createLinearGradient(0,0,0,h);grad.addColorStop(0,'#42d6a426');grad.addColorStop(1,'#42d6a400');ctx.fillStyle=grad;ctx.fill();
  ctx.beginPath();let started=false;line.forEach((v,i)=>{if(!Number.isFinite(v))return;if(!started){ctx.moveTo(xAt(i),yAt(v));started=true;}else ctx.lineTo(xAt(i),yAt(v));});ctx.setLineDash([4,4]);ctx.strokeStyle='#b49cff';ctx.lineWidth=1.2;ctx.stroke();ctx.setLineDash([]);
  const now = candles.at(-1).time; const first=candles[0].time; const fmt = ts => new Date(ts).toLocaleDateString([], { month:'short',day:'numeric' }); $('chartStart').textContent=fmt(first); $('chartEnd').textContent=fmt(now);
}
function updateSizing() {
  $('buyBudget').value = $('accountValue').value;
  $('buyRisk').value = $('riskPercent').value;
  const a = state.analyses.get(state.selected);
  if (!a?.levels || !a.price) { $('plannedRisk').textContent = '—'; $('positionValue').textContent = '—'; $('sizingNote').textContent = 'A rule-aligned setup is needed to calculate an illustrative size.'; if (state.page === 'buys') renderBestBuys(); return; }
  const plan = plannedPosition(a), quantity = plan.value / a.price;
  $('plannedRisk').textContent = money(plan.lossAtStop, 2);
  $('positionValue').textContent = money(plan.value, 2);
  $('sizingNote').textContent = plan.minimum && plan.value < plan.minimum
    ? `Estimated order value is below this pair’s ${money(plan.minimum, 2)} minimum. Skip it unless the budget is high enough.`
    : `Approx. ${quantity.toPrecision(4)} ${a.symbol.replace('USDT','')}; capped at your entered budget and ${$('riskPercent').value || 0}% stop-risk target. Excludes fees/slippage.`;
  if (state.page === 'buys') renderBestBuys();
}
async function refreshMarket(showToast = false) {
  if (state.loading) { state.marketPending = true; return; }
  state.loading = true; $('refreshButton').classList.add('spinning');
  try {
    const snapshot = await window.marketAPI.getSnapshot(INTERVALS[state.horizon], state.watchlist);
    state.snapshot = snapshot; state.lastGoodAt = snapshot.fetchedAt; buildAnalyses(); renderSummary(); renderTable(); renderSelected();
    if (showToast) toast('Market data refreshed.');
  } catch (error) {
    renderSummary();
    $('marketStatus').textContent = 'Data feed unavailable'; $('connectionLabel').textContent = 'Feed temporarily unavailable'; $('connectionMessage').textContent = error?.message || 'Check your internet connection';
    document.querySelectorAll('.pulse-dot').forEach(dot => dot.classList.add('offline'));
    $('freshTag').innerHTML = '<i></i> Stale';
    if (showToast) toast('Could not refresh. Showing the last successful snapshot.');
  } finally {
    state.loading = false; $('refreshButton').classList.remove('spinning');
    if (state.marketPending) { state.marketPending = false; refreshMarket(); }
  }
}
let toastTimer;
function toast(message) { const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2300); }
function openMethod() { $('methodDialog').showModal(); }
function changeHorizon(horizon) {
  if (!INTERVALS[horizon] || state.horizon === horizon) return;
  state.horizon = horizon; $('horizonSelect').value = horizon; $('buyHorizon').value = horizon;
  state.scannerSnapshot = null; state.scannerAnalyses = []; state.scannerFetchedAt = null;
  renderBestBuys(); refreshMarket(); refreshBuyScan();
}
$('horizonSelect').addEventListener('change', e => changeHorizon(e.target.value));
$('buyHorizon').addEventListener('change', e => changeHorizon(e.target.value));
$('marketSearch').addEventListener('input', () => { state.catalogPage=1; renderCatalog(); });
$('catalogRefresh').addEventListener('click', () => loadCatalog(true));
$('catalogPrev').addEventListener('click', () => { state.catalogPage=Math.max(1,state.catalogPage-1); renderCatalog(); });
$('catalogNext').addEventListener('click', () => { state.catalogPage++; renderCatalog(); });
$('tvOpenSymbol').addEventListener('click', () => renderTradingViewChart(true));
$('tvSymbolInput').addEventListener('keydown', e => { if (e.key === 'Enter') renderTradingViewChart(true); });
$('tvInterval').addEventListener('change', () => renderTradingViewChart(true));
document.querySelectorAll('.nav-item[data-page]').forEach(button => button.addEventListener('click', () => showPage(button.dataset.page)));
$('refreshButton').addEventListener('click', () => { refreshMarket(true); refreshBuyScan(true); });
$('buyScanRefresh').addEventListener('click', () => refreshBuyScan(true));
$('accountValue').addEventListener('input',updateSizing); $('riskPercent').addEventListener('input',updateSizing);
$('buyBudget').addEventListener('input',()=>{ $('accountValue').value=$('buyBudget').value; updateSizing(); });
$('buyRisk').addEventListener('input',()=>{ $('riskPercent').value=$('buyRisk').value; updateSizing(); });
$('editWatchlistButton').addEventListener('click',openWatchlistEditor);
$('watchlistAddButton').addEventListener('click',addWatchlistCoin);
$('watchlistSymbolInput').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();addWatchlistCoin();}});
$('methodButton').addEventListener('click',openMethod); $('methodLink').addEventListener('click',openMethod); $('disclaimerButton').addEventListener('click',openMethod);
window.addEventListener('resize',()=>{const a=state.analyses.get(state.selected);if(a)renderChart(a);});
document.querySelector('.eyebrow').childNodes[0].textContent = new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date()).toUpperCase() + ' ';
renderBestBuys();
refreshMarket(); refreshBuyScan(); setInterval(()=>refreshMarket(),120000); setInterval(()=>refreshBuyScan(),300000);
