# Crypto Signal Desk

A Windows desktop market dashboard with a searchable market catalog, an interactive TradingView chart, an editable personal watchlist, and a market-wide buy-setup scan. It does not connect to an exchange account, send orders, or hold API keys.

## Start on Windows

Run `Crypto Signal Desk 1.2.0.exe` from the `release` folder. The portable app needs an internet connection for current Binance market data and TradingView charts. Your watchlist refreshes every two minutes; the market-wide opportunity scan refreshes every five minutes. If Binance is unreachable, the last successful snapshot remains visible and is marked stale.

The executable is not code-signed. Windows may show its standard publisher confirmation for apps downloaded from outside the Microsoft Store.

## What a setup means

- **Short term:** 15-minute trigger candles with 1-hour confirmation.
- **Swing:** 4-hour trigger candles with 1-day confirmation.
- **Long term:** 1-day trigger candles with 1-week confirmation.
- **Indicators:** EMA 20/50, RSI 14, MACD histogram, candle direction, volume comparison, Bollinger bands, and ATR 14.
- **Confluence:** a 0–100 checklist score. It is not a probability, win rate, or claim of predictive accuracy.
- **Strategies:** trend continuation, 20-candle breakout with volume confirmation, trend pullback, and a Bollinger-band rebound in an upward higher-timeframe trend. Each strategy has separate rules; none has a guaranteed edge.
- **Setup threshold:** trend signals require aligned EMA and MACD direction, trigger price on the trend side of EMA 20, RSI in range, and confluence of at least 72. The other strategies have their own price, volume, RSI, and higher-timeframe conditions.
- **Example risk levels:** entry is the latest observed market price; stop distance is 1.5 × trigger-timeframe ATR (with a 0.4% minimum); target is 2R. These are illustrative levels, not exchange orders. They do not account for fees, slippage, gaps, or funding.
- **Position planner:** estimates notional from the entered budget, chosen risk percentage, and entry-to-stop distance, capped at the budget. The default $100 budget and 0.5% risk are editable examples, not a recommended allocation. Pair minimum order sizes can make very small estimates untradeable. Leverage is excluded.

## Markets and charts

- **All markets** searches every currently tradable Binance Spot pair quoted in USDT and lets you open its chart.
- **Charts** embeds TradingView's Advanced Chart widget, with its own symbol search, chart types, timeframes, indicators, and drawing tools. Use the chart's symbol search to find crypto markets supported by TradingView across its available exchanges.
- **Watchlist** is editable, supports up to 50 Binance Spot USDT pairs, and is stored locally on this PC. It only controls the overview table.
- **Best buys now** scans Binance Spot USDT markets independently from the watchlist. It screens active pairs with at least $2 million of 24-hour quote volume and ranks every coin matching one of the strategies. Lower-volume markets and markets without candle data are excluded. When no strategy qualifies, the page shows the closest long-side candidates as WAIT and issues no trade levels.
- The market-wide scanner covers Binance Spot USDT pairs, not every exchange or every TradingView market. The embedded TradingView chart can search a wider set of markets than the signal scanner.

TradingView provides the chart and its own market coverage in the embedded widget. The chart needs an internet connection and may show different data availability or price than Binance Spot. TradingView's [Advanced Chart widget documentation](https://www.tradingview.com/widget-docs/widgets/charts/advanced-chart) describes the embeddable interactive chart and symbol-change option.

Short ideas are hypothetical. Shorting generally requires derivatives or margin and can involve liquidation and losses that are not modeled by this app. A WAIT reading is intentional when the rules do not align.

## Market data

The app requests public Binance Spot market data without account credentials. Data quality and availability depend on Binance, internet access, regional availability, and API limits. Spot prices can differ across exchanges. Binance's official API documentation describes the public Spot REST API and market data: <https://developers.binance.com/en/docs/products/spot/rest-api>.

The signal engine uses transparent fixed rules; it does not train or run a machine-learning model. Scores measure rule agreement, not the probability of profit. No strategy can reliably predict every crypto market move or guarantee a profit. A small budget still carries the risk of losing the amount put into a trade; position estimates do not include fees or slippage. The app is for research and education, not individualized financial advice.

## Build the Windows portable executable

With Node.js installed, open a terminal in this folder and run:

```powershell
pnpm install
pnpm dist:win
```

The build output will be `release/Crypto Signal Desk 1.2.0.exe`. Electron's official distribution guide covers packaging and code signing: <https://www.electronjs.org/docs/latest/tutorial/application-distribution>.
